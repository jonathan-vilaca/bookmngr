import 'package:flutter/cupertino.dart';

var cod = TextEditingController();
var liv = TextEditingController();
var gen = TextEditingController();
var ne = TextEditingController();
var edi = TextEditingController();
var aut = TextEditingController();
var anoLa = TextEditingController();

clearTextInput(){
  cod.clear();
  liv.clear();
  gen.clear();
  ne.clear();
  edi.clear();
  aut.clear();
  anoLa.clear();
}