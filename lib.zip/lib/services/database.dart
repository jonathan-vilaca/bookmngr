import 'package:cloud_firestore/cloud_firestore.dart';

var db = Firestore.instance;